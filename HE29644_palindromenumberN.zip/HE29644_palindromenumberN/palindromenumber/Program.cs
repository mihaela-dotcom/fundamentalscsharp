﻿//This C# console application checks whether a number entered by the user is a **palindrome** — a number that reads the same forwards and backwards (e.g., 121, 1331).

using System;//Importing the System namespace to use built-in classes like Console

//Declaring a namespace to logically group related classes
namespace LogicalPrograms
{
    //Declaring the Program class
    class Program
    {
        static void Main(string[] args) //Main method: Entry point of the program
        {
            char choice; //Variable to store user's choice to continue or exit

            do
            {
                int num, temp, revNum = 0, rem;

                //Prompt the user to enter a number
                Console.WriteLine("Enter a number:");

                //Read the input number
                num = Convert.ToInt32(Console.ReadLine());

                //Store the original number
                temp = num;

                //Logic to reverse the number
                while (num > 0)
                {
                    rem = num % 10;              //Get the last digit of the number
                    revNum = revNum * 10 + rem;  //Build reversed number
                    num = num / 10;              //Remove the last digit from the number
                }

                //Check if the number is a palindrome
                if (revNum == temp)
                    Console.WriteLine("Number is Palindrome");
                else
                    Console.WriteLine("Number is not Palindrome");

                //Ask the user if they want to check another number
                Console.WriteLine("Do you want to check another number? (y/n): ");
                string? input = Console.ReadLine();
                if(!string.IsNullOrEmpty (input))
                choice = Convert.ToChar(input);
                else
                    choice = 'n';//default to "n" if input is null or empty

                    Console.WriteLine(); // For spacing

            } while (choice == 'y' || choice == 'Y'); //Loop continues if user enters 'y' or 'Y'

            Console.WriteLine("Program ended.");
            Console.ReadLine(); //Wait before closing
        }
    }
}