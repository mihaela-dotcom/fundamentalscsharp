#  Palindrome Number Checker (C# Console App)

This C# console application checks whether a number entered by the user is a **palindrome** — a number that reads the same forwards and backwards (e.g., 121, 1331).

##  Features

- Reverses the entered number and compares it to the original
- Tells the user if the number is a palindrome
- Asks if the user wants to check another number
- Loops until the user chooses to exit

##  Sample Interaction
Enter a number:
121
Number is Palindrome
Do you want to check another number? (y/n):
y

Enter a number:
123
Number is not Palindrome
Do you want to check another number? (y/n):
n
Program ended.

##  Note

- Input must be a valid integer.
- You can extend this program to support negative numbers, strings, or phrases.