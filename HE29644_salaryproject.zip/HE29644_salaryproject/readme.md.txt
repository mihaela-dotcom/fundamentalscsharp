#  Salary Calculator (C# Console App)

This C# console application calculates an employee’s "net salary" after a 30% deduction. It collects the employee's name, department, and salary, then displays a summary with the calculated values.

##  Features

- Accepts employee name and department
- Parses and validates salary input
- Calculates:
  -  Original Salary
  -  Deduction (30%)
  -  Net Salary
- Handles missing or invalid input gracefully

##  Sample Output
Please enter your name: Alice
What is your department: HR
What is your salary: 5000

--- Salary Summary ---
Name: Alice
Department: HR
Original Salary: 5,000.00
Deduction (30%): 1,500.00
Net Salary: 3,500.00

##  Note

- The deduction rate is fixed at 30%
- Invalid salary input defaults to 0
- Can be extended with bonus, tax brackets, or multi-user input
