﻿//This C# console application calculates an employee’s *net salary* after a 30% deduction.
//It collects the employee's name, department, and salary, then displays a summary with the calculated values.

using System;

namespace salaryproject
{
    class Program //Program class to define the main functionality
    {
        static void Main() //Main method: entry point for the program
        {
            //Displaying a welcome message to the user
            Console.WriteLine("Welcome to the department application");

            //Declare string variables with nullable type
            string? nameInput, staffInput;

            //Declare numeric variables
            double salary = 0, deduction, netsalary;

            //Prompting for name and check for null or empty
            Console.Write("Please enter your name: ");
            nameInput = Console.ReadLine();
            string Name = string.IsNullOrWhiteSpace(nameInput) ? "Unknown" : nameInput;

            //Prompting for department and check for null or empty
            Console.Write("What is your department: ");
            staffInput = Console.ReadLine();
            string staff = string.IsNullOrWhiteSpace(staffInput) ? "Not specified" : staffInput;

            //Prompting for salary and safely parsing
            Console.Write("What is your salary: ");
            string? salaryInput = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(salaryInput) && double.TryParse(salaryInput, out double parsedSalary))
            {
                salary = parsedSalary;
            }
            else
            {
                Console.WriteLine("Invalid salary input. Defaulting salary to 0.");
            }

            //Calculating deduction and net salary
            deduction = salary * 0.3;
            netsalary = salary - deduction;

            //Displaying result
            Console.WriteLine("\n--- Salary Summary ---");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Department: {staff}");
            Console.WriteLine($"Original Salary: {salary:C}");
            Console.WriteLine($"Deduction (30%): {deduction:C}");
            Console.WriteLine($"Net Salary: {netsalary:C}");

            Console.ReadLine(); //Wait before closing
        }
    }
}
