#  Rectangle Area Calculator (C# Console App)

This is a simple C# console application that calculates the **area of a rectangle** based on user input for the rectangle's length and width.

##  Features

- Prompts the user for `length` and `width`
- Calculates the area using the formula: `area = length × width`
- Displays the result in the console

##  Sample Output
Welcome to my calculation in the area of Rectangle
Please enter the length value of the area:
10
Please enter the width value of the area:
5
Total area of rectangle is = 50

##  Note

- Input must be valid integers
- Can be extended to support different shapes or units of measurement