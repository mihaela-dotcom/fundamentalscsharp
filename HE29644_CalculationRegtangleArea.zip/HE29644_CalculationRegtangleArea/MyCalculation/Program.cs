﻿//This is a simple C# console application that calculates the *area of a rectangle* based on user input for the rectangle's length and width.
using System;
namespace MyCalculation
    {
    class Program //Class to perform rectangle area calculation
    {
        static void Main()//Main method: entry point of the program
        {
            //Display a welcome message to the user
            Console.WriteLine("Welcome to my calculation in the area of Regtangle");

            //Declare variables to store area, length, and width
            int area, length, width;

            //Prompt user for length and read the input
            Console.WriteLine("Please enter the length value of the area");
            length = Convert.ToInt32(Console.ReadLine());

            //Prompt user for width and read the input
            Console.WriteLine("Please enter the width value of the area");
            width = Convert.ToInt32(Console.ReadLine());

            //Calculate the area of the rectangle
            area = length * width;

            //Display the calculated area
            Console.WriteLine("Total area of regtangle is=" + area);

        }
    }
}
