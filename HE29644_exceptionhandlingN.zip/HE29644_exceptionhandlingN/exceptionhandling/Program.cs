﻿//This C# console application demonstrates how to use try, catch, finally, and rethrowing exceptions effectively.

using System;//For console and exception handling

class UsingExceptions
{
    static void Main()
    {
        //Calling method that does not throw any exception
        Console.WriteLine("Calling DoesNotThrowException");
        DoesNotThrowException();

        //Calling method that throws and catches an exception
        Console.WriteLine("\nCalling ThrowExceptionWithCatch");
        ThrowExceptionWithCatch();

        //Calling method that throws an exception without a catch inside
        //but handled here in Main
        Console.WriteLine("\nCalling ThrowExceptionWithoutCatch");
        //ThrowExceptionWithoutCatch();
        try
        {
            ThrowExceptionWithoutCatch();
        }
        catch
        {
            Console.WriteLine("Caught exception from ThrowExceptionWithoutCatch in Main");
        }

        //Calling method that catches and rethrows an exception
        //which is then caught in Main
        Console.WriteLine("\nCalling ThrowExceptionCatchRethrow");
        try
        {
            ThrowExceptionCatchRethrow();
        }
        catch
        {
            Console.WriteLine("Caught exception from ThrowExceptionCatchRethrow in Main");
        }
    }

    //Method that does not throw any exception
    static void DoesNotThrowException()
    {
        try
        {
            Console.WriteLine("In DoesNotThrowException");
        }
        catch
        {

            //This block is never executed because no exception is thrown
            Console.WriteLine("This catch never executes");
        }
        finally
        {

            //This block always executes, regardless of exception
            Console.WriteLine("finally executed in DoesNotThrowException");
        }
        Console.WriteLine("End of DoesNotThrowException");
    }

    //Method that throws an exception and handles it in a catch block
    static void ThrowExceptionWithCatch()
        {
            try
            {
                Console.WriteLine("In ThrowExceptionWithCatch");
                throw new Exception("Exception in ThrowExceptionWithCatch");
            }
            catch (Exception exceptionParameter)
            {
            //Catching and displaying the exception message
            Console.WriteLine($"Message:{exceptionParameter.Message}");
            }
            finally
            {
            //Executes regardless of exception
            Console.WriteLine("finally executed in ThrowExceptionWWithCatch");
            }
            Console.WriteLine("End of ThrowExceptionWithCatch");
        }

    //Method that throws an exception without a catch block
    //The exception is not handled here, but it is caught in Main
    static void ThrowExceptionWithoutCatch()
        {
            try
            {
                Console.WriteLine("In ThrowExceptionWithoutCatch");
                throw new Exception("Exception in ThrowExceptionWithoutCatch");
            }

            finally
            {
            //Finally block still executes even though there's no catch
            Console.WriteLine("finally executed in ThrowExceptionWithoutCatch");
            }
        //This line never executes because the exception is thrown above
       // Console.WriteLine("End of ThrowExceptionWithoutCatch");    
        }

    //Method that catches an exception, logs it, then rethrows it
    static void ThrowExceptionCatchRethrow()
        {
            try
            {
                Console.WriteLine("In ThrowExceptionCatchRethrow");
                throw new Exception("Exception in ThrowExceptionCatchRethrow");
            }
            catch(Exception exceptionParameter)
            {

            //Log the message, then rethrow the exception to be handled by the caller
            Console.WriteLine("Message:"+ exceptionParameter.Message);
                throw;
            }
            finally
            {
            //Finally block always executes
            Console.WriteLine("finally executed in ThrowExceptionCatchRethrow");
            }
        //This line is unreachable due to rethrow
        //Console.WriteLine("End of ThrowExceptionCatchRethrow");
        }
}