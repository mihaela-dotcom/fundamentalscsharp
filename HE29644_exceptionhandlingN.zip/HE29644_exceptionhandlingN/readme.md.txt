#  Exception Handling Demo (C#)

This C# console application demonstrates how to use **`try`**, **`catch`**, **`finally`**, and **rethrowing exceptions** effectively.

It contains multiple methods to illustrate different exception-handling scenarios.

##  Features

-  `DoesNotThrowException()`  
  Shows a `try-catch-finally` block where no exception occurs.

-  `ThrowExceptionWithCatch()`  
  Throws an exception and handles it with a local `catch` block.

-  `ThrowExceptionWithoutCatch()`  
  Throws an exception, no local catch, but it's caught in `Main()`.

-  `ThrowExceptionCatchRethrow()`  
  Catches an exception, logs it, and rethrows it for `Main()` to handle.

##  Sample Output (Simplified)

Calling DoesNotThrowException
In DoesNotThrowException
finally executed in DoesNotThrowException
End of DoesNotThrowException

Calling ThrowExceptionWithCatch
In ThrowExceptionWithCatch
Message: Exception in ThrowExceptionWithCatch
finally executed in ThrowExceptionWWithCatch
End of ThrowExceptionWithCatch

Calling ThrowExceptionWithoutCatch
In ThrowExceptionWithoutCatch
finally executed in ThrowExceptionWithoutCatch
Caught exception from ThrowExceptionWithoutCatch in Main

Calling ThrowExceptionCatchRethrow
In ThrowExceptionCatchRethrow
Message: Exception in ThrowExceptionCatchRethrow
finally executed in ThrowExceptionCatchRethrow
Caught exception from ThrowExceptionCatchRethrow in Main

##  Note

This is a learning example and demonstrates control flow during exceptions. You can extend it with custom exception types or logging tools.

