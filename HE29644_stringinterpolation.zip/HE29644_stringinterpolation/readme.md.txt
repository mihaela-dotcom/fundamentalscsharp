
#  Vegetable Price Tracker (C# Console App)

This C# console application defines a simple class `Vegetable` to represent a vegetable by name and uses an `enum` to describe units of measurement. It displays the price of a vegetable along with the current date.

##  Features

- Uses a custom `Vegetable` class
- Defines an `enum` for units: `item`, `kilogram`, `gram`, `dozen`
- Formats:
  - Date (`short date format`)
  - Price (`currency with 2 decimal places`)
- Demonstrates object-oriented concepts like constructors, properties, and method overriding

##  Sample Output
On 5/19/2025, the price of eggplant was $1.99 per item

##  Note

- The vegetable, unit, and price are hardcoded (eggplant, item, $1.99)
- You can extend the program to accept user input or handle multiple vegetables