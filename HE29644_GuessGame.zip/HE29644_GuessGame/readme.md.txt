#  Number Guessing Game (C# Console App)

This C# console application is a simple and fun **number guessing game**. The program generates a random number between 1 and 10, and the player must guess it. The game gives feedback on each guess and continues until the correct number is guessed.

##  Features

- Random number generation between **1 and 10**
- Feedback for **too high**, **too low**, or **correct** guesses
- Loop continues until the correct guess is made

##  Sample Gameplay
Welcome to the number guessing name
A number between 1 and 10 will be generated.
If you guess the correct number, you win!
Please enter your guess:

5
Your guess is too low.
Please enter your guess:
9
Correct!
Congratulations, you have won the game!

##  Note

- Input is expected to be an integer between 1 and 10.
- You can expand this game with difficulty levels, attempt limits, or score tracking.