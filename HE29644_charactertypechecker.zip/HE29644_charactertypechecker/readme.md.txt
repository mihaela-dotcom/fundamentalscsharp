#  Character Type Checker (C# Console App)

This C# console application classifies user input as one of the following types:

- **Vowel**
- **Consonant**
- **Integer**
- **Float**
- **Boolean**
- **Special Symbol**
- **Unrecognized**

The program runs continuously until the user types `"exit"` to quit.

##  Features

- Identifies single characters (vowel, consonant, digit, or symbol)
- Detects multi-character input types:
  - Integer (e.g., `123`)
  - Float (e.g., `45.67`)
  - Boolean (`true` or `false`)
- Easy to use and beginner-friendly

##  Example
Enter a character or value or type 'exit' to quit : a
The character is a vowel.

Enter a character or value or type 'exit' to quit : 7
The character is an integer.

Enter a character or value or type 'exit' to quit : false
The input is a boolean.

Enter a character or value or type 'exit' to quit : $
The character is a special symbol or other.

##  Note

- The program uses `Console.ReadKey()` after each result to pause for user review.
- Input is case-insensitive and continues running until `"exit"` is entered.

