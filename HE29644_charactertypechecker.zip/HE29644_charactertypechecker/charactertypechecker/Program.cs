﻿//This program is designed to classify an input provided by the user as a character, integer, float, boolean,
//or special symbol, and it keeps running until the user types "exit" to quit.
using System;

namespace CharacterTypeChecker
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Character Type Checker");
            Console.WriteLine("Type any value to identify its type, or type 'exit' to quit.\n");

            //Infinite loop to keep the program running until the user exits
            while (true)
            {
                Console.Write("Enter a character or value (or type 'exit' to quit): ");
                string? input = Console.ReadLine();

                //Exit condition
                if (input == null || input.Trim().ToLower() == "exit")
                {
                    Console.WriteLine("Program exited. Goodbye!");
                    break;
                }

                input = input.Trim(); //Remove leading/trailing whitespace

                //Check for single-character input
                if (input.Length == 1)
                {
                    char ch = input[0];

                    if ("aeiouAEIOU".IndexOf(ch) >= 0)
                    {
                        Console.WriteLine("The character is a **vowel**.");
                    }
                    else if (char.IsLetter(ch))
                    {
                        Console.WriteLine("The character is a **consonant**.");
                    }
                    else if (char.IsDigit(ch))
                    {
                        Console.WriteLine("The character is an **integer digit**.");
                    }
                    else
                    {
                        Console.WriteLine("The character is a **special symbol or punctuation**.");
                    }
                }
                //Multi-character input (string of length > 1)
                else
                {
                    if (int.TryParse(input, out int intResult))
                    {
                        Console.WriteLine("The input is an **integer**.");
                    }
                    else if (float.TryParse(input, out float floatResult))
                    {
                        Console.WriteLine("The input is a **float**.");
                    }
                    else if (bool.TryParse(input, out bool boolResult))
                    {
                        Console.WriteLine("The input is a **boolean**.");
                    }
                    else
                    {
                        Console.WriteLine("The input type is **unrecognized**.");
                    }
                }

                Console.WriteLine(); //Blank line for better readability
            }
        }
    }
}