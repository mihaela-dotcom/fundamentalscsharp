#  Guess the Number Game plus attempts(C# Console App)

This is a simple C# console application where the program randomly selects a number between 1 and 10, and the user tries to guess it. The game gives feedback after each guess and continues until the correct number is found.

##  Features

- Random number generation between 1 and 10
- Input validation (ensures guess is a valid number within range)
- Feedback for too low / too high guesses
- Tracks and displays number of attempts

##  Sample Gameplay
Welcome to the Guess the Number game!
I have selected a number between 1 and 10. Can you guess what it is?
Please enter your number:

5
Too low! Try again.
8
Too high! Try again.
7
Congratulations! You've guessed the correct number 7 in 3 attempts.
Thank you for playing!

##  Note

- Invalid or out-of-range input is handled gracefully.
- You can enhance this with difficulty levels, retry options, or player statistics.