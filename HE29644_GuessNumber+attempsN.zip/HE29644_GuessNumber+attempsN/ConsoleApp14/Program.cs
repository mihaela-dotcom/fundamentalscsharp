﻿//This is a simple C# console application where the program randomly selects a number between 1 and 10, and the user tries to guess it. The game gives feedback after each guess and continues until the correct number is found.
using System; //Required for console input/output

namespace MyProject
{
    class Program
    {
        static void Main()
        {

            //Define the minimum and maximum range for the random number
            int min = 1;
            int max = 10;

            //Create a Random object to generate a number
            Random random = new Random();

            //Generate a random number between min and max (inclusive)
            int targetNumber = random.Next(min, max + 1);

            //Initialise attempt counter and guess variable
            int attemps = 0; //Tracks number of guesses
            int guess = 0; //Stores the user's current guess

            //Welcome message
            Console.WriteLine("Welcome to the Guess the Number game!");
            Console.WriteLine($"I have selected a number between {min} and {max}. Can you guess what it is?");

            //Loop until the user guesses the correct number
            while (guess != targetNumber)
            {
                attemps++; //Increment attempts for each try
                Console.WriteLine("Please enter your number:");

                //Read user input
                string? input = Console.ReadLine();

                //Validate if input is an integer
                bool isValid = int.TryParse(input, out guess);

                //Check if input is invalid or out of range
                if (!isValid || guess < min || guess > max)
                {
                    Console.WriteLine($"Please enter a valid number between {min} and {max}");
                    continue; //Skip rest of loop and ask again

                }

                //Provide feedback to the user based on the guess
                if (guess < targetNumber)
                {
                    Console.WriteLine("Too Low! try again.");

                }
                else if (guess > targetNumber)
                {
                    Console.WriteLine("Too high! try again.");

                }
            }

            //Success message when the correct number is guessed
            Console.WriteLine($"Congratulations! You've guessed the correct number {targetNumber} in {attemps} attemps.");

            //Farewell message
            Console.WriteLine("Thank you for playing!");
        }
    }
}