﻿//This C# console application prompts a user for their name and then collects grades for six academic modules. It calculates and displays the average grade with proper validation.

using System;

//Prompt the user to enter their name
Console.WriteLine("Please enter your name:");
string? name = Console.ReadLine(); //Read the user's name

//Define a method to collect grades and calculate the average
void method()
{
    double avg=0.0; //store total sum to compute average
    double[] grade = new double[6]; //Array to store grades for 6 modules

    //Array of module names to prompt user input dynamically
    string[] modules = new string[]
    {
        "English",
        "Math",
        "Physics",
        "Computer Science",
        "Academic Skills",
        "Database"
    };

    //Loop through each module and collect grades
    for (int i = 0; i < modules.Length; i++)
    {
        Console.WriteLine($"Please enter a grade for {modules[i]} module:");

        //Validate and parse user input safely
        string? input = Console.ReadLine();

        //try to parse safely; if null or invalid, set to 0
        if (!string.IsNullOrWhiteSpace(input) && double.TryParse(input, out double parsedGrade))
        {
            grade[i] = parsedGrade; // Store the valid grade in the array
        }
        else
        {
            Console.WriteLine("Invalid input. Grade set to 0.");
            grade[i] = 0.0; //Default value in case of invalid input
        }
   

        avg += grade[i]; //Sum all grades
    }
    avg = avg / grade.Length; //calculate the average

    //Display the average rounded to the nearest whole number
    Console.WriteLine($"\n{name}, your average grade is: {avg:F2}");

    Console.ReadLine(); //Wait for user to press Enter before closing
}

//Call the method to execute the grade processing logic
method();