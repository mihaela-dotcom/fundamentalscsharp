#  Module Grade Average (C# Console App)

This C# console application prompts a user for their name and then collects grades for six academic modules. It calculates and displays the average grade with proper validation.

##  Features

- Prompts for grades in six modules:
  - English
  - Math
  - Physics
  - Computer Science
  - Academic Skills
  - Database
- Validates input and defaults invalid entries to 0
- Displays the average grade formatted to two decimal places

##  Sample Output
Please enter your name:
Alice
Please enter a grade for English module:
90
...
Alice, your average grade is: 85.33

##  Note

- Non-numeric or empty inputs are treated as `0`.
- Can be extended with grade classification (A, B, C...) or input from a file.