﻿//This simple C# console application allows users to input a number and view its reversed form. The program repeats until the user chooses to exit.

using System;//Import the System namespace to use built-in classes like Console

namespace Reverse //Define a namespace for the program
{
    class Program //Define the Program class
    {
        static void Main(string[] args) //Main method - program execution starts here
        {
            char choice; //Variable to store the user's decision to continue or not

            //Start a loop to allow the user to reverse multiple numbers
            do
            {
                //Declare variables
                int number, remainder, revNumber = 0;

                //Ask the user to enter a number
                Console.Write("Enter a number to reverse: ");
                string? input = Console.ReadLine(); //Read user input as string (can be null)

                //Validate input
                if (!int.TryParse(input, out number))
                {
                    //If conversion fails, show an error message
                    Console.WriteLine("Invalid input. Please enter a valid integer.");
                }
                else
                {
                    //Reverse the number using a loop
                    int temp = number;

                    //Loop to reverse the number digit by digit
                    while (temp > 0)
                    {
                        remainder = temp % 10; //Get the last digit of the number
                        revNumber = (revNumber * 10) + remainder; //Build the reversed number
                        temp = temp / 10; //Remove the last digit
                    }

                    //Output the reversed number
                    Console.WriteLine("Reversed number is: {0}", revNumber);
                }

                //Ask if the user wants to continue
                Console.Write("Do you want to reverse another number? (y/n): ");
                string? again = Console.ReadLine(); //Read the user's choice

                //Convert the input to a char, use 'n' if input is null or empty
                choice = (!string.IsNullOrEmpty(again)) ? Convert.ToChar(again) : 'n';

                Console.WriteLine(); //Print a blank line for better readability

            } while (choice == 'y' || choice == 'Y'); //Repeat the loop if user enters 'y' or 'Y'

            //Print goodbye message when the program ends
            Console.WriteLine("Program ended.");
        }
    }
}