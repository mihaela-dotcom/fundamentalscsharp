#  Number Reverser (C# Console App)

This simple C# console application allows users to input a number and view its **reversed** form. The program repeats until the user chooses to exit.

##  Features

- Accepts user input as an integer
- Reverses the number using a digit-by-digit loop
- Validates input to ensure it's a valid integer
- Option to reverse multiple numbers in one session

##  Sample Interaction
Enter a number to reverse: 1234
Reversed number is: 4321
Do you want to reverse another number? (y/n): y

Enter a number to reverse: 500
Reversed number is: 5
Do you want to reverse another number? (y/n): n

Program ended.

##  Note

- Input must be a positive integer.
- Invalid input is handled with an error message.
- Can be extended to handle negative numbers or strings.