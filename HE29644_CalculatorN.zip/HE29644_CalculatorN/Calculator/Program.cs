﻿//This C# console application allows users to perform basic arithmetic operations: *addition, subtraction, multiplication, and division*.
//It validates inputs and handles division by zero gracefully.

using System;
namespace Calculator
   
    {
        class Program
        {
            static void Main()
            {
                //Declare variables to store user input and result
                float num1, num2, result;
                string? answer;

                //Welcome message
                Console.WriteLine("Hello, welcome to the calculator program!");

                //Prompt for first number and validate input
                Console.Write("Please enter your first number: ");
                while (!float.TryParse(Console.ReadLine(), out num1))
                {
                    Console.Write("Invalid input. Please enter a valid number: ");
                }

                //Prompt for second number and validate input
                Console.Write("Please enter your second number: ");
                while (!float.TryParse(Console.ReadLine(), out num2))
                {
                    Console.Write("Invalid input. Please enter a valid number: ");
                }

                //Ask user to choose an operation
                Console.WriteLine("What type of operation would you like to perform?");
                Console.WriteLine("Enter:");
                Console.WriteLine("  a - Addition");
                Console.WriteLine("  s - Subtraction");
                Console.WriteLine("  m - Multiplication");
                Console.WriteLine("  d - Division");

                //Read and normalize user input
                answer = Console.ReadLine()?.ToLower();

                //Perform operation based on user input
                switch (answer)
                {
                    case "a":
                        result = num1 + num2;
                        break;
                    case "s":
                        result = num1 - num2;
                        break;
                    case "m":
                        result = num1 * num2;
                        break;
                    case "d":
                        if (num2 == 0)
                        {
                            Console.WriteLine("Cannot divide by 0!");
                            Console.ReadKey();
                            return; //Exit the program early
                        }
                        result = num1 / num2;
                        break;
                    default:
                        Console.WriteLine("Invalid operation selected.");
                        Console.ReadKey();
                        return; //Exit on invalid input
                }

                //Display result
                Console.WriteLine($"The result is: {result}");

                //Thank you message
                Console.WriteLine("Thank you for using the calculator program!");

                //Wait before exiting
                Console.ReadKey();
            }
        }
    }