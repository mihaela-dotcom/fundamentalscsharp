#  Simple Calculator (C# Console App)

This C# console application allows users to perform basic arithmetic operations: **addition, subtraction, multiplication, and division**. It validates inputs and handles division by zero gracefully.

##  Features

- Accepts two numbers from the user
- Supports operations:
  - `a` – Addition
  - `s` – Subtraction
  - `m` – Multiplication
  - `d` – Division
- Validates numeric input
- Handles invalid operations and division by zero

##  Sample Output
Hello, welcome to the calculator program!
Please enter your first number: 10
Please enter your second number: 2
Enter:
a - Addition
s - Subtraction
m - Multiplication
d - Division

m
The result is: 20
Thank you for using the calculator program!

## Note

- Non-numeric input is rejected with a helpful message
- You can extend this program with a repeat loop or advanced functions (e.g., power, square root)