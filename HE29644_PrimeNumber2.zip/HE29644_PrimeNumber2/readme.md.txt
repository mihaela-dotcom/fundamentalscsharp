#  Prime Number Checker 2 (C# Console App)

This C# console application checks whether a given number is **prime** or not. It continuously prompts the user until they choose to exit by typing `"exit"`.

##  Features

- Accepts user input for a number
- Validates the input
- Determines whether the number is a **prime**
- Continues running until the user types **exit**

##  Sample Output
Enter a Number (or type 'exit' to quit): 7
7 is Prime.

Enter a Number (or type 'exit' to quit): 9
9 is not Prime.

Enter a Number (or type 'exit' to quit): exit

##  Note

- A prime number is a number greater than 1 with no divisors other than 1 and itself.
- You can enhance this program with performance optimizations or a GUI.