﻿//This C# program is designed to check whether a given number is prime or not
using System;

using System;

namespace PrimeNumber2
{
    public class Program
    {
        static void Main()
        {
            Console.WriteLine("Prime Number Checker");
            Console.WriteLine("Type a number to check if it's prime or type 'exit' to quit.\n");

            while (true)
            {
                //Prompt for input
                Console.Write("Enter a Number (or type 'exit' to quit): ");
                string? input = Console.ReadLine();

                //Exit condition
                if (input != null && input.Trim().ToLower() == "exit")
                {
                    Console.WriteLine("\nExiting the program. Goodbye!");
                    break;
                }

                //Try parsing the input to an integer
                if (int.TryParse(input, out int number))
                {
                    //Negative numbers and 0/1 are not prime
                    if (number <= 1)
                    {
                        Console.WriteLine($"{number} is not Prime.\n");
                        continue;
                    }

                    bool isPrime = true;

                    //Only check up to the square root of the number
                    int limit = (int)Math.Sqrt(number);
                    for (int i = 2; i <= limit; i++)
                    {
                        if (number % i == 0)
                        {
                            isPrime = false;
                            break;
                        }
                    }

                    if (isPrime)
                        Console.WriteLine($"{number} is Prime.\n");
                    else
                        Console.WriteLine($"{number} is not Prime.\n");
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer.\n");
                }
            }
        }
    }
}