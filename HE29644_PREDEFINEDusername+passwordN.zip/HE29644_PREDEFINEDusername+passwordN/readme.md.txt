#  Console Login Application (C#)

This is a simple C# console-based login application that verifies user credentials against predefined values. It allows the user to repeatedly attempt login until they choose to exit.

##  Features

- Prompts for username and password
- Verifies credentials against hardcoded values:
  - Username: `sunny`
  - Password: `Sunny1`
- Provides feedback for success or failure
- Allows the user to retry or exit
- Friendly UI with emoji-based prompts

##  Sample Interaction
 Enter your username: sunny
 Enter your password: Sunny1

Login Successful! Welcome, sunny!

Enter 0 to Exit or any other number to try again: 0

Thank you for using the Login Application. Goodbye!

##  Note

- This is a static demo with hardcoded credentials.
- You can extend it with:
  - Registration and password encryption
  - File or database-based credential storage