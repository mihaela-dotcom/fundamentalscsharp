﻿//This is a console-based login application written in C# which check predefined username and password
using System;

namespace ConsoleApp21
{
    class Program
    {
        static void Main()
        {
            //use for emojis
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            //Declare login variables
            string username, password;
            string validUsername = "sunny";  //predefined correct username
            string validPassword = "Sunny1"; //predefined correct password

            int cont; //Used to control program repetition

            //Welcome Banner
            Console.WriteLine("|************************************************|");
            Console.WriteLine("|*           PROGRAM TO LOGIN APPLICATION       *|");
            Console.WriteLine("|*                                              *|");
            Console.WriteLine("|*                  - LOGIN                     *|");
            Console.WriteLine("|*                  - EXIT                      *|");
            Console.WriteLine("|************************************************|");
            Console.WriteLine("\n*************** Welcome to Login Application ***************\n");

            //Start login loop
            do
            {
                //Prompt for username
                Console.Write("👤 Enter your username: ");
                username = Console.ReadLine() ?? ""; //use empty string if null

                //Prompt for password
                Console.Write("🔐 Enter your password: ");
                password = Console.ReadLine() ?? ""; //use empty string if null

                //Check if entered credentials match the valid ones
                if (username == validUsername && password == validPassword)
                {
                    Console.WriteLine("\n✅ Login Successful! Welcome, sunny!\n");
                }
                else
                {
                    Console.WriteLine("\n❌ Login Failed! Invalid username or password.\n");
                }

                //Ask if the user wants to continue or exit
                Console.Write("🔁 Enter 0 to Exit or any other number to try again: ");

                //Validate and parse the input to integer
                bool isNumber = int.TryParse(Console.ReadLine(), out cont);
                if (!isNumber)
                {
                    Console.WriteLine("⚠️ Invalid input. Restarting the program...\n");
                    cont = 1; //default to continue
                }

                Console.WriteLine(); //spacer

            } while (cont != 0); //Loop ends when user enters 0

            //Program ends gracefully
            Console.WriteLine("👋 Thank you for using the Login Application. Goodbye!");
            Environment.Exit(0); //Exit with success status
        }
    }
}
