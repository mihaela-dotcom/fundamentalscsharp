﻿using System;
using System.Windows.Forms;

namespace SmartHomeGUI
{
    static class Program
    {
       
        // The main entry point for the application.
      
        [STAThread]//specifies the COM threading model for the application as single-threaded apartment
        static void Main()
        {
            //Enables visual styles for the application (modern Windows look and feel)
            Application.EnableVisualStyles();
            //Ensures text is rendered using GDI+ (better compatibility for older components)
            Application.SetCompatibleTextRenderingDefault(false);
            //Launches the main user interface (MainForm)
            Application.Run(new MainForm());
        }
    }
}