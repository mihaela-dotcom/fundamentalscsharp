﻿namespace SmartHomeGUI
{
    partial class MainForm
    {
        //UI components declarations
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnTurnOnLights;
        private System.Windows.Forms.Button btnTurnOffLights;
        private System.Windows.Forms.Button btnSetTemperature;
        private System.Windows.Forms.Button btnPlayMusic;
        private System.Windows.Forms.Button btnStopMusic;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel panelLights;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TrackBar trackBarVolume;
        private System.Windows.Forms.NumericUpDown numericTemperature;

        //clean up any resources being used
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        //method where all UI components are initialised and configured
        private void InitializeComponent()
        {
            //instantiate and set properties for buttons, controls 
            this.btnTurnOnLights = new System.Windows.Forms.Button();
            this.btnTurnOffLights = new System.Windows.Forms.Button();
            this.btnSetTemperature = new System.Windows.Forms.Button();
            this.btnPlayMusic = new System.Windows.Forms.Button();
            this.btnStopMusic = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.panelLights = new System.Windows.Forms.Panel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.trackBarVolume = new System.Windows.Forms.TrackBar();
            this.numericTemperature = new System.Windows.Forms.NumericUpDown();

            //begin UI layout setup
            ((System.ComponentModel.ISupportInitialize)(this.trackBarVolume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericTemperature)).BeginInit();
            this.SuspendLayout();
            
            //btnTurnOnLights
            this.btnTurnOnLights.Location = new System.Drawing.Point(30, 30);
            this.btnTurnOnLights.Name = "btnTurnOnLights";
            this.btnTurnOnLights.Size = new System.Drawing.Size(190, 40);
            this.btnTurnOnLights.TabIndex = 0;
            this.btnTurnOnLights.Text = "Turn On Lights";
            
            //btnTurnOffLights
            this.btnTurnOffLights.Location = new System.Drawing.Point(245, 30);
            this.btnTurnOffLights.Name = "btnTurnOffLights";
            this.btnTurnOffLights.Size = new System.Drawing.Size(168, 40);
            this.btnTurnOffLights.TabIndex = 1;
            this.btnTurnOffLights.Text = "Turn Off Lights";
            
            //btnSetTemperature
            this.btnSetTemperature.Location = new System.Drawing.Point(30, 90);
            this.btnSetTemperature.Name = "btnSetTemperature";
            this.btnSetTemperature.Size = new System.Drawing.Size(190, 40);
            this.btnSetTemperature.TabIndex = 2;
            this.btnSetTemperature.Text = "Set Temperature";
       
            //btnPlayMusic
            this.btnPlayMusic.Location = new System.Drawing.Point(30, 150);
            this.btnPlayMusic.Name = "btnPlayMusic";
            this.btnPlayMusic.Size = new System.Drawing.Size(190, 40);
            this.btnPlayMusic.TabIndex = 3;
            this.btnPlayMusic.Text = "Play Music";
  
            //btnStopMusic
            this.btnStopMusic.Location = new System.Drawing.Point(245, 150);
            this.btnStopMusic.Name = "btnStopMusic";
            this.btnStopMusic.Size = new System.Drawing.Size(168, 40);
            this.btnStopMusic.TabIndex = 4;
            this.btnStopMusic.Text = "Stop Music";
 
            //btnExit
            this.btnExit.Location = new System.Drawing.Point(160, 470);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 43);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "Exit";

            //panelLights-visual indicator for light status
            this.panelLights.BackColor = System.Drawing.Color.Gray;
            this.panelLights.Location = new System.Drawing.Point(431, 21);
            this.panelLights.Name = "panelLights";
            this.panelLights.Size = new System.Drawing.Size(265, 150);
            this.panelLights.TabIndex = 7;
  
            //lblStatus-displays status message
            this.lblStatus.Location = new System.Drawing.Point(30, 374);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(420, 30);
            this.lblStatus.TabIndex = 8;
            this.lblStatus.Text = "Status messages appear here.";
    
            //trackBarVolume-volume control for music
            this.trackBarVolume.Location = new System.Drawing.Point(35, 249);
            this.trackBarVolume.Maximum = 100;
            this.trackBarVolume.Name = "trackBarVolume";
            this.trackBarVolume.Size = new System.Drawing.Size(250, 90);
            this.trackBarVolume.TabIndex = 6;

            //numericTemperature-numeric input for temperature setting
            this.numericTemperature.Location = new System.Drawing.Point(245, 96);
            this.numericTemperature.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericTemperature.Name = "numericTemperature";
            this.numericTemperature.Size = new System.Drawing.Size(60, 31);
            this.numericTemperature.TabIndex = 12;
            this.numericTemperature.Value = new decimal(new int[] {
            22,
            0,
            0,
            0});

            // MainForm settings
            this.ClientSize = new System.Drawing.Size(741, 561);
            this.Controls.Add(this.btnTurnOnLights);
            this.Controls.Add(this.btnTurnOffLights);
            this.Controls.Add(this.btnSetTemperature);
            this.Controls.Add(this.btnPlayMusic);
            this.Controls.Add(this.btnStopMusic);
            this.Controls.Add(this.trackBarVolume);
            this.Controls.Add(this.panelLights);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.numericTemperature);
            this.Name = "MainForm";
            this.Text = "Smart Home Control Panel";
            
            //finalise layout
            ((System.ComponentModel.ISupportInitialize)(this.trackBarVolume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericTemperature)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}