﻿//Smart Home GUI

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using WMPLib;//Windows Media Player library for audio playback

namespace SmartHomeGUI
{
    public partial class MainForm : Form
    {
        //Windows Media Player instance for playing music
        private WindowsMediaPlayer player = new WindowsMediaPlayer();

        //path to the local music file
        private readonly string musicFilePath = "C:\\Users\\bmsim\\source\\repos\\ProjectSmartHomeAssistantwindowsform\\SmartHomeAssistant\\bin\\Debug\\happy-feels-all-good.mp3";

        //Timer used for blinking light animation
        private Timer blinkTimer = new Timer();
        private bool isBlinkOn = true;//toggle state for blinking

        //Light Themes definition
        private Theme lightTheme = new Theme
        {
            BackgroundColor = Color.White,
            PanelColor = Color.LightYellow,
            ButtonColor = Color.LightBlue,
            TextColor = Color.Black
        };
        //dark theme definition
        private static readonly Theme theme = new Theme
        {
            BackgroundColor = Color.FromArgb(30, 30, 30),
            PanelColor = Color.FromArgb(45, 45, 48),
            ButtonColor = Color.DimGray,
            TextColor = Color.White
        };
        private Theme darkTheme = theme;

        public MainForm()
        {
            InitializeComponent();

            //Assign event handlers to buttons
            btnTurnOnLights.Click += HandleSmartHomeAction;
            btnTurnOffLights.Click += HandleSmartHomeAction;
            btnSetTemperature.Click += HandleSmartHomeAction;
            btnPlayMusic.Click += HandleSmartHomeAction;
            btnStopMusic.Click += HandleSmartHomeAction;
            btnExit.Click += HandleSmartHomeAction;

            //assign event handler to Volume track bar 
            trackBarVolume.Scroll += trackBarVolume_Scroll;

            //Apply default light theme
            ApplyTheme(lightTheme);

            //configure and start blink timer for light animation
            blinkTimer.Interval = 500;//milliseconds
            blinkTimer.Tick += BlinkLights;
            blinkTimer.Start();

            //Initialize default volume
            player.settings.volume = 50;
            trackBarVolume.Value = 50;
        }

        //apply a theme to the form and its controls
        private void ApplyTheme(Theme theme)
        {
            this.BackColor = theme.BackgroundColor;
            lblStatus.ForeColor = theme.TextColor;
            panelLights.BackColor = theme.PanelColor;

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Button btn)
                {
                    btn.BackColor = theme.ButtonColor;
                    btn.ForeColor = theme.TextColor;
                }

                if (ctrl is TrackBar track)
                    track.BackColor = theme.PanelColor;

                if (ctrl is NumericUpDown num)
                    num.BackColor = theme.PanelColor;
            }
        }

        //handles all button click actions in the smart home interface
        private void HandleSmartHomeAction(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton == null) return;

            switch (clickedButton.Name)
            {
                case "btnTurnOnLights":
                    panelLights.BackColor = Color.Yellow;
                    lblStatus.Text = "💡 Lights are now ON.";
                    break;

                case "btnTurnOffLights":
                    panelLights.BackColor = Color.Gray;
                    lblStatus.Text = "🕧️ Lights are now OFF.";
                    break;

                case "btnSetTemperature":
                    int temp = (int)numericTemperature.Value;
                    if (temp > 32)
                    {
                        lblStatus.Text = $"🔥 Temperature set to {temp}°C. It's hot!";
                        panelLights.BackColor = Color.OrangeRed;
                    }
                    else if (temp < 10)
                    {
                        lblStatus.Text = $"🧊 Temperature set to {temp}°C. It's cold!";
                        panelLights.BackColor = Color.LightBlue;
                    }
                    else
                    {
                        lblStatus.Text = $"🌡️ Temperature set to {temp}°C.";
                        panelLights.BackColor = Color.LightGreen;
                    }
                    break;

                case "btnPlayMusic":
                    if (File.Exists(musicFilePath))
                    {
                        player.controls.stop(); // Reset playback
                        player.URL = musicFilePath;
                        player.controls.play();
                        lblStatus.Text = "🎵 Playing your favourite music.";
                        trackBarVolume.Value = player.settings.volume;
                    }
                    else
                    {
                        MessageBox.Show($"Music file '{musicFilePath}' not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    break;

                case "btnStopMusic":
                    player.controls.stop();
                    player.URL = string.Empty; // Clear URL to prevent replay
                    lblStatus.Text = "⏹️ Music stopped.";
                    break;

                case "btnExit":
                    DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        MessageBox.Show("👋 Bye! See you soon.", "Exit", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Application.Exit();
                    }
                    break;

                default:
                    lblStatus.Text = "❓ Unknown action.";
                    break;
            }
        }

        //toggles the panel light color to simulate blinking
        private void BlinkLights(object sender, EventArgs e)
        {
            if (panelLights.BackColor == Color.Yellow || panelLights.BackColor == Color.Gold)
            {
                panelLights.BackColor = isBlinkOn ? Color.Gold : Color.Yellow;
                isBlinkOn = !isBlinkOn;
            }
        }

        //update the volume based on the track bar value
        private void trackBarVolume_Scroll(object sender, EventArgs e)
        {
            player.settings.volume = trackBarVolume.Value;
            lblStatus.Text = $"🔊 Volume set to {trackBarVolume.Value}%";
        }
        //placeholder for form load event
        private void MainForm_Load(object sender, EventArgs e)
        {

        }
        
    }
//class representing a visual theme with customizable colors
    public class Theme
    {
        public Color BackgroundColor { get; set; }
        public Color PanelColor { get; set; }
        public Color ButtonColor { get; set; }
        public Color TextColor { get; set; }
    }
}
