﻿namespace AxWMPLib
{
    internal class AxWindowsMediaPlayer
    {
        public AxWindowsMediaPlayer()
        {
        }
    }
}