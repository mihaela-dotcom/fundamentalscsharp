# Smart Home GUI

A Windows Forms-based Smart Home Control Panel built using C#. This project simulates basic smart home operations, including lighting control, temperature setting, and music playback.

## Features

-  Turn lights on/off with visual panel feedback
-  Set and display indoor temperature with colour cues
-  Play and stop background music using Windows Media Player
-  Adjust music volume with a track bar
-  Light and dark theme support (customizable in code)
-  Exit confirmation with a friendly goodbye message

## Requirements

- Windows OS
- .NET Framework (compatible with Windows Forms)
- Visual Studio (recommended for development)

## Getting Started

1. *Clone the repository* or download the source code.
2. Open the solution file (`.sln`) in Visual Studio.
3. Build and run the project.

## File Info

- `MainForm.cs`: Handles logic and event handling.
- `MainForm.Designer.cs`: Contains the UI layout setup.
- `Program.cs`: Entry point for the application.
- `happy-feels-all-good.mp3`: Music file used for playback (you can replace it).


## License

This project is for educational use. Modify and expand freely!