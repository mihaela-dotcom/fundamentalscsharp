﻿//This C# console application simulates a basic online shopping form where users are asked to enter their personal details like name, address, email, and phone number.
//The input is then validated and confirmed before proceeding.

using System;

namespace Shopping
{
    class Program
    {
        static void Main(string[] args)
        {
            //use for emojis
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            //Welcome banner with shopping emoji
            Console.WriteLine("======================================");
            Console.WriteLine("     🛒 Welcome to Online Shopping!");
            Console.WriteLine("======================================\n");

            //Declare variables
            string? name, address, email;
            string? telInput;
            double tel;
            bool detailsConfirmed = false;

            //Collect user details with icons
            Console.Write("👤 Please enter your full name: ");
            name = Console.ReadLine();

            Console.Write("🏠 Please enter your address: ");
            address = Console.ReadLine();

            Console.Write("📧 Please enter your email address: ");
            email = Console.ReadLine();

            //Validate and parse contact number
            do
            {
                Console.Write("📞 Please enter your contact number: ");
                telInput = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(telInput) && double.TryParse(telInput, out tel))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("⚠️ Invalid input. Please enter a valid contact number.\n");
                }
            } while (true);

            //Display the details entered
            Console.WriteLine("\n🔎 Please review your details:");
            Console.WriteLine("==========================================");
            Console.WriteLine($"👤 Name    : {name}");
            Console.WriteLine($"🏠 Address : {address}");
            Console.WriteLine($"📧 Email   : {email}");
            Console.WriteLine($"📞 Contact : {tel}");
            Console.WriteLine("==========================================");

            //Confirm with user
            Console.Write("\n✅ Are these details correct? (yes/no): ");
            string? confirmation = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(confirmation) &&
                confirmation.Trim().ToLower() == "yes")
            {
                detailsConfirmed = true;
            }

            //Final message with icon
            if (detailsConfirmed)
            {
                Console.WriteLine("\n🎉 Thank you! Your details have been confirmed.");
                Console.WriteLine("🛍️ You can now proceed with your online shopping!");
            }
            else
            {
                Console.WriteLine("\n❌ Your details were not confirmed. Please try again.");
            }

            Console.WriteLine("\n🔚 Press Enter to exit...");
            Console.ReadLine();
        }
    }
}