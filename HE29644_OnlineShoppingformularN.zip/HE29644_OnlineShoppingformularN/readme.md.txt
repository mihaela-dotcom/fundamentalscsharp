#  Online Shopping User Details (C# Console App)

This C# console application simulates a basic online shopping form where users are asked to enter their personal details like name, address, email, and phone number. The input is then validated and confirmed before proceeding.

##  Features

- Collects and displays:
  -  Full Name
  -  Address
  -  Email
  -  Contact Number
- Validates numeric input for contact number
- Uses emojis for a friendly, modern console UI
- Confirms user input before proceeding

##  Sample Interaction
 Please enter your full name: Alice
 Please enter your address: 123 Main Street
 Please enter your email address: alice@email.com
 Please enter your contact number: 1234567890

 Please review your details:
 Name : Alice
 Address : 123 Main Street
 Email : alice@email.com
 Contact : 1234567890

 Are these details correct? (yes/no): yes
 Thank you! Your details have been confirmed.
 You can now proceed with your online shopping!

##  Note

- Input is handled gracefully with validation for phone numbers.
- Can be expanded with a shopping cart or product selection features.
