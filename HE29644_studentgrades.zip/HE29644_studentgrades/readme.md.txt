#  Student Grade Evaluator (C# Console App)

This C# console application takes a student's name and numeric grade as input and displays the corresponding **letter grade** based on standard grading criteria.

##  Features

- Accepts student name and grade input
- Evaluates and displays letter grades:
  - **A** (90 and above)
  - **B** (80–89)
  - **C** (70–79)
  - **D** (60–69)
  - **F** (below 60)
- Displays personalized messages for each student

##  Sample Output
Welcome to my new application design student calculations grades
Please enter student name
Alice
Please enter student grade
85
Alice Congratulations your grade is B

##  Note

- Input must be a valid integer between 0 and 100.
- You can extend this to handle multiple students or validate input more robustly.