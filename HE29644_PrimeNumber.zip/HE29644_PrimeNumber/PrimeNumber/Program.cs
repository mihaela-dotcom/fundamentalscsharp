﻿//This C# program is designed to find and display all prime numbers between a user-defined range of numbers.
using System;
namespace LogicalPrograms
{
    public class Program
    {
        // Main method: Entry point of the program
        static void Main(string[] args)
        {
            // Prompt the user to enter the starting number
            Console.Write("Enter The Start Number: ");
            // Parse the input string to an integer and store it in startNumber
            int startNumber = int.Parse(Console.ReadLine());

            // Prompt the user to enter the ending number
            Console.Write("Enter the End Number : ");

            // Convert the input string to an integer and store it in endNumber
            int endNumber = Convert.ToInt32(Console.ReadLine());

            // Display a message indicating that prime numbers between the two numbers will be shown
            Console.WriteLine($"The Prime Numbers between {startNumber} and {endNumber} are : ");

            // Outer loop to iterate through each number between startNumber and endNumber
            for (int i = startNumber; i <= endNumber; i++)
            {
                // Initialize a counter to track if the number is divisible by any number
                int counter = 0;

                // Inner loop to check divisibility of the number 'i' by all numbers from 2 to i/2
                for (int j = 2; j <= i / 2; j++)
                {
                    // If 'i' is divisible by 'j', it's not a prime number
                    if (i % j == 0)
                    {
                        // Increment counter and break the loop since it's not prime
                        counter++;
                        break;
                    }
                }
                // If counter is 0 and i is not 1, then 'i' is a prime number
                if (counter == 0 && i != 1)
                {
                    // Print the prime number
                    Console.Write("{0} ", i);
                }
            }

            // Wait for the user to press a key before closing the console window
            Console.ReadKey();
        }
    }
}