#  Prime Number Finder (C# Console App)

This C# console application finds and displays all **prime numbers** between a user-defined start and end value.

##  Features

- Prompts the user to enter a **start** and **end** number
- Checks each number in the range to determine if it's prime
- Displays all prime numbers in the specified range

##  Sample Output
Enter The Start Number: 10
Enter the End Number : 30
The Prime Numbers between 10 and 30 are :
11 13 17 19 23 29

##  Note

- This version uses a basic algorithm for checking primes.
- You can improve performance by checking up to `√n` or using the Sieve of Eratosthenes for large ranges.