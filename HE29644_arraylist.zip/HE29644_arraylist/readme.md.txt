# Student Grade Evaluator in C# using array list #

This is a simple C# console application that evaluates the grades of students based on their marks. It uses two arrays: one to store student names and another to store their corresponding marks. Based on each student's mark, the program assigns a letter grade (A–D) with a descriptive message.

##  Features

- Uses arrays to manage student data.
- Automatically assigns grades based on score ranges:
  - **A** – Excellent (90+)
  - **B** – Very Good (80–89)
  - **C** – Average (70–79)
  - **D** – Just Passed (60–69)

##  How to Run

1. Open the project in Visual Studio or any C# IDE.
2. Build and run the application.
3. View the output displaying each student and their assigned grade.

##  Example Output
Sam Grade: C Average
Maria Grade: B Very Good
Miha Grade: A Excelent
Ana Grade: A Excelent
David Grade: C Average
Vicky Grade: D Just Passed


##  Note

This is a static example — the student data and marks are hardcoded. You can easily expand it by allowing user input or reading from a file.
