# Advanced Calculator in C#

This is a simple interactive C# console application that performs basic arithmetic operations: **addition, subtraction, multiplication, and division**. The user is prompted to input two numbers and select an operation. The program runs in a loop, allowing multiple calculations until the user chooses to exit.

##  Features

- Supports: `+`, `-`, `*`, `/`
- Uses a `do-while` loop for repeated calculations
- Gracefully handles invalid operation input

## Sample Interaction

Calculator Program
Please enter number 1: 10
Please enter number 2: 5
Please enter an option:
+ : Add
- : Subtract
* : Multiply
/ : Divide
Please enter an option: *
Your result: 10 * 5 = 50
Would you like to continue? (Y = yes, N = No): Y

##  Note

This version assumes valid numeric input. You can expand it by adding error handling for invalid numbers or division by zero.