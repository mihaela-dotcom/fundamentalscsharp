#  Letter Grades Analyzer (C# Console App)

This C# console application reads a list of student grades (0–100) from user input and calculates:

- Total number of grades
- Class average
- Count of each letter grade (A–F)

It uses a `switch` statement to classify grades into:
- **A** (90–100)
- **B** (80–89)
- **C** (70–79)
- **D** (60–69)
- **F** (<60)

##  Features

- Accepts an unlimited number of grades
- Calculates and displays the class average
- Provides a summary of how many students got each grade
- Ends input when the user presses `Ctrl + Z` (on Windows)

##  Sample Output
Enter the integer grades in the range 0-100.
Type < Ctrl> z and press Enter to terminate input:
90
85
76
64
52
^Z

Grade Report:
Total of the 5 grades entered is 367
Class average is 73.4
Number of students who received each grade:
A:1
B:1
C:1
D:1
F:1

##  Note

- Input must be integers between 0 and 100.
- End input with `Ctrl + Z` followed by Enter (Windows) or `Ctrl + D` (Linux/macOS).
