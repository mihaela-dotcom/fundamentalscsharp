﻿//This C# console application reads a list of student grades (0–100) from user input and calculates:
//Total number of grades
//Class average
//Count of each letter grade (A–F)

using System;//Import the System namespace to use Console and other basic classes
class LetterGrades //Define the class that contains the program
{
    static void Main() //Entry point of the program
    {
        //Declare variables to track totals and counts
        int total = 0; // Holds the sum of all grades
        int gradeCounter = 0; //Counts how many grades were entered

        //Counters for each letter grade
        int aCount = 0; //Count of A grades (90–100)
        int bCount = 0; //Count of B grades (80–89)
        int cCount = 0; //Count of C grades (70–79)
        int dCount = 0; //Count of D grades (60–69)
        int fCount = 0; //Count of F grades (<60)


        //Prompt the user for input
        Console.WriteLine("Enter the integer grades in the range 0-100.");
        Console.WriteLine("Type < Ctrl> z and press Enter to terminate input:");

        //Read the first input line
        string? input = Console.ReadLine();
        //Loop as long as input is not null (null means end-of-input on Ctrl+Z)
        while (input != null)
        {
            //Convert the string input to an integer grade
            int grade = int.Parse(input);
            //Add the grade to the total and increment the counter
            total += grade;
            ++gradeCounter;

            //Use switch-case to determine the letter grade group
            switch (grade / 10) //Integer division simplifies grouping (e.g., 97/10 = 9)
            {
                case 9: //Grades 90–99
                case 10: //Grade 100
                    ++aCount;
                    break;
                case 8: //Grades 80–89
                    ++bCount;
                    break;
                case 7: //Grades 70–79
                    ++cCount;
                    break;
                case 6: //Grades 60–69
                    ++dCount;
                    break;
                default: //Grades < 60
                    ++fCount;
                    break;

            }
            //Read the next input
            input = Console.ReadLine();
        }

        //Display the final grade report
        Console.WriteLine("\nGrade Report:");

        //Check if any grades were entered
        if (gradeCounter != 0)
        {
            //Calculate and display average
            double average = (double) total / gradeCounter;
            Console.WriteLine($"Total of the {gradeCounter} grades entered is {total}");

            //Format average to 1 decimal place
            Console.WriteLine($"Class average is {average:F}");

            //Display the number of each letter grade received
            Console.WriteLine("Number of studens who received each grade:");
            Console.WriteLine($"A:{aCount}");
            Console.WriteLine($"B:{bCount}");
            Console.WriteLine($"C:{cCount}");
            Console.WriteLine($"D:{dCount}");
            Console.WriteLine($"F:{fCount}");

        }
        else
        {
            //If no grades were entered, display a message
            Console.WriteLine("No grades were entered");
        }
    }
}